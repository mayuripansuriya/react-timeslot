export const GET_ALL_SLOTS = 'GET_ALL_SLOTS';
export const GET_SINGLE_SLOT = 'GET_SINGLE_SLOT';
export const STORE_SLOT = 'STORE_SLOT';